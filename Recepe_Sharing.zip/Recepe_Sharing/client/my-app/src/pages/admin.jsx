import { useEffect, useState } from 'react';
import api from '../api';

export default function Admin() {
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    api.get('/recipes').then((res) => setRecipes(res.data));
  }, []);

  const remove = async (id) => {
    if (!window.confirm('Delete this recipe?')) return;
    await api.delete(`/recipes/${id}`);
    setRecipes(recipes.filter(r => r._id !== id));
  };

  return (
    <div className="container mt-4">
      <h2>Admin Dashboard</h2>
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Created</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {recipes.map(r => (
            <tr key={r._id}>
              <td>{r.title}</td>
              <td>{r.author?.name}</td>
              <td>{new Date(r.createdAt).toLocaleDateString()}</td>
              <td>
                <button className="btn btn-danger btn-sm" onClick={() => remove(r._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
