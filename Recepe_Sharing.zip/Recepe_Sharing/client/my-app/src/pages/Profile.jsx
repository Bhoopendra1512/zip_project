import useAuth from '../hooks/useAuth';

export default function Profile() {
  const { user } = useAuth();
  if (!user) return null;
  return (
    <div className="container mt-4">
      <div className="card p-4 shadow">
        <h2>Profile</h2>
        <p><b>Name:</b> {user.name}</p>
        <p><b>Email:</b> {user.email}</p>
      </div>
    </div>
  );
}
