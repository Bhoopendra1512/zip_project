import { useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';

export default function AddRecipe() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [ingredients, setIngredients] = useState([{ name: '', quantity: '' }]);
  const [steps, setSteps] = useState(['']);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    const { data } = await api.post('/recipes', { title, description, imageUrl, ingredients, steps });
    navigate(`/recipes/${data._id}`);
  };

  return (
    <div className="container mt-4" style={{ maxWidth: 640 }}>
      <form onSubmit={submit} className="card p-4 shadow">
        <h2 className="mb-3">Add Recipe</h2>
        <input className="form-control mb-3" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea className="form-control mb-3" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
        <input className="form-control mb-3" placeholder="Image URL" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} />

        <h4>Ingredients</h4>
        {ingredients.map((ing, idx) => (
          <div key={idx} className="d-flex gap-2 mb-2">
            <input className="form-control" placeholder="Name" value={ing.name} onChange={(e) => {
              const copy = [...ingredients];
              copy[idx].name = e.target.value; setIngredients(copy);
            }} />
            <input className="form-control" placeholder="Qty" value={ing.quantity} onChange={(e) => {
              const copy = [...ingredients];
              copy[idx].quantity = e.target.value; setIngredients(copy);
            }} />
          </div>
        ))}
        <button type="button" className="btn btn-secondary mb-3" onClick={() => setIngredients([...ingredients, { name: '', quantity: '' }])}>+ Ingredient</button>

        <h4>Steps</h4>
        {steps.map((s, idx) => (
          <input key={idx} className="form-control mb-2" placeholder={`Step ${idx + 1}`} value={s} onChange={(e) => {
            const copy = [...steps];
            copy[idx] = e.target.value; setSteps(copy);
          }} />
        ))}
        <button type="button" className="btn btn-secondary mb-3" onClick={() => setSteps([...steps, ''])}>+ Step</button>

        <button className="btn btn-success">Save</button>
      </form>
    </div>
  );
}
