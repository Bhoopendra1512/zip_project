export default function Home() {
  return (
    <div className="container text-center mt-5">
      <h1 className="mb-3">Welcome to the Recipe App</h1>
      <p className="lead">Browse, create, and share your favorite recipes.</p>
    </div>
  );
}
