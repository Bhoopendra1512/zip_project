import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api';

export default function RecipeDetail() {
  const { id } = useParams();
  const [r, setR] = useState(null);
  const [comment, setComment] = useState('');

  useEffect(() => {
    api.get(`/recipes/${id}`).then((res) => setR(res.data));
  }, [id]);

  const submitComment = async (e) => {
    e.preventDefault();
    await api.post(`/recipes/${id}/comments`, { text: comment });
    const { data } = await api.get(`/recipes/${id}`);
    setR(data);
    setComment('');
  };

  if (!r) return <p className="text-center mt-5">Loading...</p>;

  return (
    <div className="container mt-4">
      <h2>{r.title}</h2>
      <img src={r.imageUrl || '/static/images/placeholder.jpg'} alt={r.title} className="img-fluid rounded mb-3" style={{ maxWidth: 500 }} />
      <p>{r.description}</p>

      <h4>Ingredients</h4>
      <ul className="list-group mb-3">
        {r.ingredients?.map((ing, i) => (
          <li key={i} className="list-group-item">{ing.quantity ? `${ing.quantity} ` : ''}{ing.name}</li>
        ))}
      </ul>

      <h4>Steps</h4>
      <ol className="list-group list-group-numbered mb-3">
        {r.steps?.map((s, i) => (
          <li key={i} className="list-group-item">{s}</li>
        ))}
      </ol>

      <h4>Comments</h4>
      <ul className="list-group mb-3">
        {r.comments?.map((c, i) => (
          <li key={i} className="list-group-item"><strong>{c.user?.name || 'User'}:</strong> {c.text}</li>
        ))}
      </ul>

      <form onSubmit={submitComment} className="d-flex">
        <input className="form-control me-2" placeholder="Add a comment" value={comment} onChange={(e) => setComment(e.target.value)} />
        <button className="btn btn-primary">Post</button>
      </form>
    </div>
  );
}
