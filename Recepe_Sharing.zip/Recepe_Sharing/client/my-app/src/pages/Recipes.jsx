import { useEffect, useState } from 'react';
import api from '../api';
import RecipeCard from '../components/RecipeCard';

export default function Recipes() {
  const [recipes, setRecipes] = useState([]);
  const [q, setQ] = useState('');

  useEffect(() => {
    api.get('/recipes').then((res) => setRecipes(res.data));
  }, []);

  const search = async (e) => {
    e.preventDefault();
    const { data } = await api.get('/recipes', { params: { q } });
    setRecipes(data);
  };

  return (
    <div className="container mt-4">
      <form onSubmit={search} className="d-flex mb-4">
        <input className="form-control me-2" placeholder="Search recipes..." value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn btn-outline-success">Search</button>
      </form>
      <div className="row g-4">
        {recipes.map((r) => (
          <div key={r._id} className="col-md-4 col-sm-6">
            <RecipeCard r={r} />
          </div>
        ))}
      </div>
    </div>
  );
}
