import { Link } from 'react-router-dom';

export default function RecipeCard({ r }) {
  return (
    <div className="card shadow-sm h-100">
      <img src={r.imageUrl || '/static/images/placeholder.jpg'} className="card-img-top" alt={r.title} />
      <div className="card-body">
        <h5 className="card-title">{r.title}</h5>
        <p className="card-text">{r.description?.slice(0, 80)}...</p>
        <Link to={`/recipes/${r._id}`} className="btn btn-primary">Open</Link>
      </div>
    </div>
  );
}
