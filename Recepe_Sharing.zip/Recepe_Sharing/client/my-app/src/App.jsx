import { Routes, Route, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import useAuth from './hooks/useAuth';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Recipes from './pages/Recipes';
import RecipeDetail from './pages/RecipeDetail';
import AddRecipe from './pages/AddRecipe';
import Profile from './pages/Profile';
import Protected from './components/Protected';
import Admin from './pages/Admin';

export default function App() {
  const { user, loading, logout } = useAuth();
  const navigate = useNavigate();

  if (loading) return <p className="text-center mt-5">Loading...</p>;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      {/* ✅ Bootstrap Navbar */}
      <Navbar user={user} onLogout={handleLogout} />

      {/* ✅ Main Container for Pages */}
      <main className="container my-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/recipes" element={<Recipes />} />
          <Route path="/recipes/:id" element={<RecipeDetail />} />
          <Route
            path="/add"
            element={
              <Protected user={user}>
                <AddRecipe />
              </Protected>
            }
          />
          <Route
            path="/admin"
            element={
              <Protected user={user}>
                {user?.role === 'admin' ? <Admin /> : <p className="mt-5 text-center">Access Denied</p>}
              </Protected>
            }
          />
          <Route
            path="/profile"
            element={
              <Protected user={user}>
                <Profile />
              </Protected>
            }
          />
        </Routes>
      </main>
    </>
  );
}
