import Recipe from '../models/Recipe.js';
import User from '../models/User.js';

// List all recipes (with optional search by title)
export const list = async (req, res) => {
  const { q } = req.query;
  const filter = q ? { title: { $regex: q, $options: 'i' } } : {};
  const recipes = await Recipe.find(filter).populate('author', 'name');
  res.json(recipes);
};

// Create new recipe
export const create = async (req, res) => {
  try {
    const data = { ...req.body, author: req.user.id };
    const recipe = await Recipe.create(data);
    res.status(201).json(recipe);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Get single recipe
export const getOne = async (req, res) => {
  const recipe = await Recipe.findById(req.params.id).populate('author', 'name');
  if (!recipe) return res.status(404).json({ message: 'Not found' });
  res.json(recipe);
};

// Update recipe (owner or admin)
export const update = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const query = user.role === 'admin'
      ? { _id: req.params.id } // admin can update any recipe
      : { _id: req.params.id, author: req.user.id }; // user can update only their own

    const recipe = await Recipe.findOneAndUpdate(query, req.body, { new: true });
    if (!recipe) return res.status(404).json({ message: 'Not found or not authorized' });
    res.json(recipe);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete recipe (owner or admin)
export const remove = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const query = user.role === 'admin'
      ? { _id: req.params.id } // admin can delete any recipe
      : { _id: req.params.id, author: req.user.id }; // user can delete only their own

    const recipe = await Recipe.findOneAndDelete(query);
    if (!recipe) return res.status(404).json({ message: 'Not found or not authorized' });
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Add comment to recipe
export const comment = async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ message: 'text required' });

  const recipe = await Recipe.findByIdAndUpdate(
    req.params.id,
    { $push: { comments: { user: req.user.id, text } } },
    { new: true }
  ).populate('comments.user', 'name');
  res.json(recipe);
};

// Toggle favorite (placeholder, handled client-side)
export const toggleFavorite = async (req, res) => {
  const recipe = await Recipe.findById(req.params.id);
  if (!recipe) return res.status(404).json({ message: 'Not found' });
  res.json({ message: 'Use /auth/me to fetch favorites; relation stored on user model' });
};
