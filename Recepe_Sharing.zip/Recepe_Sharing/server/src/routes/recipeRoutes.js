import { Router } from 'express';
import { auth } from '../middleware/auth.js';
import { list, create, getOne, update, remove, comment } from '../controllers/recipeController.js';
import { admin } from '../middleware/admin.js';


const router = Router();
router.delete('/:id', auth, admin, remove);
router.get('/', list);
router.get('/:id', getOne);
router.post('/', auth, create);
router.patch('/:id', auth, update);
router.delete('/:id', auth, remove);
router.post('/:id/comments', auth, comment);

export default router;